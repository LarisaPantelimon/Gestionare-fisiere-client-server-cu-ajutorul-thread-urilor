#include<arpa/inet.h>
#include <stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<string.h>
#include<strings.h>
#include<sys/socket.h>
#include<pthread.h>
#include<fcntl.h>
#include<sys/sendfile.h>
#define BUF_SIZE 4096000
int main()
{
        int clientsocket =socket(AF_INET,SOCK_STREAM,0);
        struct sockaddr_in server_address;
        server_address.sin_family=AF_INET;
        //server_address.sin_addr.s_addr="127.0.0.1";
        inet_pton(AF_INET,"127.0.0.1",&server_address.sin_addr);
        server_address.sin_port=htons(5000);

        int connection_status=connect(clientsocket,(struct sockaddr*)&server_address,sizeof(server_address));

        if(connection_status<0) printf("Eroare la conectare!\n");
        else printf("S-a conectat!!!\n");

        char message[3]="0x0";
                int n=send(clientsocket,message,strlen(message),0);
                //send(clientsocket,"mesaj",7,0);

        if(n<0) printf("Eroare la trimiterea mesajului\n");
        else printf("Mesajul a fost trimis cu succes\n");

        char buffer1[500];
        recv(clientsocket,buffer1,500,0);
        printf("%s\n",buffer1);
        
        
        return 0;
}