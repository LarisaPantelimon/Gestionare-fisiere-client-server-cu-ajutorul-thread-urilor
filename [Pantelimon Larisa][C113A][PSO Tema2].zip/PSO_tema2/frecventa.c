#include <stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<string.h>
#include<strings.h>
#include<sys/socket.h>
#include<pthread.h>


struct CuvantSiIndex
{
        int index; //aici voi avea numarul de aparitii pentru fiecare cuvant
        char *cuvant;
}CuvantSiIndex;

int comparareDescrescator(const void *a, const void *b) {
    
    return ((struct CuvantSiIndex*)b)->index - ((struct CuvantSiIndex*)a)->index;
}

char **FrecventaCuvinte(const char*filename)
{
        filename=strdup(filename+1);
        FILE *f=fopen(filename,"r");
        char buffer[100000];
        
        char buffer2[4096];
        //if(f!=NULL) strcpy(buffer,fgets())
        bzero(buffer,100000);
        bzero(buffer2,4096);
        while(fgets(buffer2,4096,f))
        {
                strcat(buffer,buffer2);
        }
        fclose(f);
        
        char *text=strdup(buffer);
        
        int numaraCuvinte=1;

        for(int i=0;i<strlen(text);i++)
        if(text[i]==' '|| text[i]=='\n')
         numaraCuvinte++; //asta va fi dimensiunea vectorului
        
        struct CuvantSiIndex *v=(struct CuvantSiIndex*)malloc(numaraCuvinte*sizeof(struct CuvantSiIndex));

        char *rest=strdup(text);

        for(int i=0;i<numaraCuvinte;i++)
        {
                v[i].index=0;
                v[i].cuvant=strtok_r(rest," \n",&rest);
        }//am populat vectorul

        //facem cautarea frecventei

        for(int i=0;i<numaraCuvinte;i++){
                for(int j=0;j<numaraCuvinte;j++)
                {
                        if(v[i].cuvant!=NULL && v[j].cuvant!=NULL){
                        if(strcmp(v[i].cuvant,v[j].cuvant)==0)
                        v[i].index++;}
                }
        }
        //acum sortam vectorul
        qsort(v, numaraCuvinte, sizeof(v[0]), comparareDescrescator);

        //aici vom avea vectorul final care ajunge la server

        //ar trebui sa elimin dublurile inainte

        for(int i=0;i<numaraCuvinte-1;i++)
        {
                for(int j=i+1;j<numaraCuvinte-1;j++)
                if(v[j].cuvant!=NULL && v[i].cuvant!=NULL){
                if(strcmp(v[i].cuvant,v[j].cuvant)==0)
               v[j].cuvant=NULL;}
        }

        char **final=(char**)malloc(10*sizeof(char*));
        int numara=0;
        
        for (int i = 0; i < numaraCuvinte; i++)
{
    if (v[i].cuvant != NULL)
    {
        if (numara < 10)
        {
            final[numara++] = strdup(v[i].cuvant);
        }
        else
        {
            break;
        }
    }
}

for (int i = numara; i < 10; i++)
{
    final[i] = strdup(" ");
}

return final;
}
