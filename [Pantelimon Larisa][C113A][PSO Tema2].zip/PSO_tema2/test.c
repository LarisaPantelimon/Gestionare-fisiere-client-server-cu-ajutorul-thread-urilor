#define _XOPEN_SOURCE 500
#include <ftw.h>
#include<arpa/inet.h>
#include <stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<string.h>
#include<strings.h>
#include<sys/socket.h>
#include<pthread.h>
#include<sys/sendfile.h>
#include"frecventa.c"
#include<fcntl.h>
#include<sys/stat.h>
#include<time.h>
#include<signal.h>
#include<sys/epoll.h>
//aici o sa stabilim si numarul de clienti
#define MAX_CLIENTI 10
#define BUF_SIZE 4096000
#define CURRENT_DIRECTORY  "."

int terminare=0; //asta e variabila prin care o sa verific daca a fost primit semnal pentru incheiera executiei printr-un semnal
//o sa am nevoie si de o functie prin care sa gestionez primirea semnalelor
struct epoll_event ev;
int efd;

pthread_t threadPrincipal;
pthread_t threadCalculeaza;

struct filedetails{
        const char* filename;
        char **cuvinte;
}filedetails;

struct filedetails CoadaFisiere[100];
int NumberOfFiles=0;

struct sendThread
{
        int serverSock;
        char buffer[4096];

}sendThread;

enum TipulOperatiei
{
        LIST=0x0,
        DOWNLOAD=0x1,
        UPLOAD=0x2,
        DELETE=0x4,
        MOVE=0x8,
        UPDATE=0x10,
        SEARCH=0x20
};

int x=1;
enum STATUS
{
        SUCCESS=0X0,
        FILE_NOT_FOUND=0x1,
        PERMISSION_DENIED=0x2,
        OUT_OF_MEMORY=0x4,
        SERVER_BUSY=0x8,
        UNKNOWN_OPERATION=0x10,
        BAD_ARGUMENTS=0x20,
        OTHER_ERROR=0x40
};

struct RequestFromClient
{
        enum TipulOperatiei RequestType;
        uint32_t dimensiune;
        char* caleFisier;
        uint32_t dimensiuneContFisier;
        char *ContinutFisier;
        uint32_t dimensiuneDestinatie;
        char* caleFisierDestinatie;
        uint32_t octetStart;
        uint32_t dimensiuneContinutNou;
        char* NewCharacters;
        uint32_t NrOctetiCuvant;
        char* Cuvant;
};

pthread_t threadClienti[MAX_CLIENTI];
int CurrentNumberOfClients=0;
pthread_cond_t cond=PTHREAD_COND_INITIALIZER;//variabila de conditie pentru primul thread

pthread_mutex_t MutexStart; //mutexul aferent
int listaCalculata=0;
//imi trebuie un mutex prin care sa protejez variabila CurrentNumberOfClients
pthread_mutex_t ProtectClients;
//o sa imi mai trebuiasca inca un mutex prin care sa protejez scrierea in fisierul de log
pthread_mutex_t protectFile;
//imi trebuie un thread prin care sa fac gestionarea semnalelor de terminare
pthread_t threadFinish;
pthread_mutex_t MutexStop;

#define PORT 5000
//am nevoie de tot atatea threaduri cati clienti am
// deci probabil o sa am nevoie de un vector de threaduri
// plus inca un thread pentru terminarea programului


//ar trebui sa mai fac un thread care sa calculeze pentru fiecare fisier 10 cele mai frecvente cuvinte

void WriteIntoLogFile(char* tipOperatie, const char*caleFisier, char* cuvantCautat)
{
        pthread_mutex_lock(&protectFile);
        int fd=open("LogFile.txt",O_WRONLY | O_APPEND);
        if(fd<0) {printf("Eroare la deschiderea fisierului!\n"); exit(-1);}

        time_t t;
        char buffer[80];
        
        time(&t);
        strcpy(buffer,ctime(&t));
        buffer[strlen(buffer)-1]=' ';
        
        char message[150];

        strcpy(message,buffer);
        strcat(message,"[ "); strcat(message,tipOperatie); strcat(message," ],");
        strcat(message,"[ "); strcat(message,caleFisier); strcat(message," ],");
        strcat(message,"[ "); strcat(message,cuvantCautat); strcat(message," ]");
        strcat(message,"\n");
        write(fd,message,strlen(message));
        close(fd);
        pthread_mutex_unlock(&protectFile);
}
int listFiles2(const char *fpath, const struct stat *sb, int typeflag, struct FTW *ftwbuf) {

    if (typeflag == FTW_F) {
        
        const char *fileExtension = strrchr(fpath, '.');
        if (fileExtension != NULL && strcmp(fileExtension, ".txt") == 0 && strcmp(fpath,"./LogFile.txt")) {
            
            //printf("%s\n", fpath);
            CoadaFisiere[NumberOfFiles++].filename=strdup(fpath+1);
            printf("%s\n",CoadaFisiere[NumberOfFiles-1].filename);
        }
    }
    return 0;
}

void signal_handler(int signum)
{
        if(signum==SIGTERM||signum==SIGINT)
        {
                printf("\nS-a primit semnal de oprire a executiei! Se incepe procesul de GRACEFUL TERMINATION!\n");
                pthread_mutex_lock(&MutexStop);
                terminare=1;
                pthread_mutex_unlock(&MutexStop);
        }
}

void* FinishExecution(void *param)
{
        efd=epoll_create1(0);
        if(efd<0) printf("Eroare la EPOLL_CREATE!\n");
        ev.events=EPOLLIN;
        ev.data.fd=STDIN_FILENO;

        if(epoll_ctl(efd,EPOLL_CTL_ADD,STDIN_FILENO,&ev)==-1)
        perror("Eroare la EPOLL_CTL\n");

        int num_events;
        struct epoll_event events[1];
       
        while((num_events=epoll_wait(efd,events,1,-1))==0)
        {
                //num_events=epoll_wait(efd,events,1,-1);

                if(num_events==-1)
                perror("Eroare la EPOLL_WAIT\n");
        }

        for(int i=0;i<num_events;i++)
        {
                if(events[i].data.fd==STDIN_FILENO)
                {
                        char buffer[256];
                        if(fgets(buffer,sizeof(buffer),stdin)!=NULL)
                        {
                                if(strcmp(buffer,"quit\n")==0)
                                {
                                        printf("S-a primit mesaj de inchidere a server-ului!\n");
                                        pthread_mutex_lock(&MutexStop);
                                        terminare=1;
                                        pthread_mutex_unlock(&MutexStop);
                                }
                        }
                }
        }
}

void* DeterminaFrecventa(void * param)
{
        while(1){
         pthread_mutex_lock(&MutexStart);
        
        NumberOfFiles=0;
        if (ftw(CURRENT_DIRECTORY, listFiles2, 10) == -1) {
        perror("ftw");
        //return 1;
    }
        if(NumberOfFiles==0)
        fprintf(stderr,"Momentan nu aveti fisiere in lista!\n");
        else{
                for(int i=0;i<NumberOfFiles;i++){
                //CoadaFisiere[i].cuvinte=(char**)malloc(sizeof(char*)*10);

                CoadaFisiere[i].cuvinte=FrecventaCuvinte(CoadaFisiere[i].filename);}
        }
               //pthread_cond_signal(&cond);
               x=1;
              listaCalculata=1;
         //pthread_cond_signal(&cond);
         printf("S-a apelat!\n");
         while(x==1)
         {
         pthread_cond_wait(&cond,&MutexStart);
         }
         pthread_mutex_unlock(&MutexStart);}
}

int CreateSocket()
{
        int serverSocket;
        struct sockaddr_in serverAddr;

        serverSocket=socket(AF_INET,SOCK_STREAM,0);
        //serverAddr.sin_addr.s_addr="127.0.0.1";
        inet_pton(AF_INET,"127.0.0.1",&serverAddr.sin_addr);
        serverAddr.sin_family=AF_INET;
        serverAddr.sin_port=htons(PORT);

        bind(serverSocket,(struct sockaddr*)&serverAddr,sizeof(serverAddr));

        int flags=fcntl(serverSocket,F_GETFL,0);
        fcntl(serverSocket,F_SETFL,flags | O_NONBLOCK);

        listen(serverSocket,MAX_CLIENTI);

        return serverSocket;
}
void ListFiles(struct RequestFromClient r, int mysocket) 
{
        printf("S-a apelat functia de listare a fisierelor\n");
        if(NumberOfFiles>0){
        int nrOctetiRaspuns=0;
        for(int i=0;i<NumberOfFiles;i++) //calculam prima data numarul de octeti raspuns
         nrOctetiRaspuns+=strlen(CoadaFisiere[i].filename);
        //asta trimtem prima data
        
        char first2[20]; sprintf(first2,"%d",SUCCESS);
        char first[20]; sprintf(first,"%d",nrOctetiRaspuns);
        char message[200];
        strcpy(message,first2);
        strcat(message,";");
        strcat(message,first);
        strcat(message,";");
        printf("%s\n",message); char nullchar='\0'; int lenghtmessage=0;
        
        for(int i=0;i<NumberOfFiles;i++)
        {
                lenghtmessage+=strlen(CoadaFisiere[i].filename);
                memcpy(message+strlen(message),CoadaFisiere[i].filename,lenghtmessage);
                memcpy(message+strlen(message),&nullchar,1);

        }
        int n=send(mysocket,message,strlen(message)+1,MSG_DONTWAIT);
        if(n<0)
        {
                char message[20];
                char convert[20];
                sprintf(convert,"%d",OTHER_ERROR);
                strcpy(message,convert);
                send(mysocket,message,strlen(message)+1,0); 
        }
        char director[20];
        bzero(director,20);
        getcwd(director,20);
        WriteIntoLogFile("LIST",director,"");
        printf("Am iesit\n");
}
}
void DownloadFile(struct RequestFromClient r, int mysocket) 
{
        
        int gasit=0;
        for(int i=0;i<NumberOfFiles;i++)
        if(strcmp(r.caleFisier,CoadaFisiere[i].filename)==0){
                gasit=1;
                break;
        }
        if(gasit==0)
        {
                //trimitem codul de eroare file not found
                //care este 0X1
                r.caleFisier=strdup(r.caleFisier+1);
                char message[20];
                char numar[20];
                char convert[20];
                sprintf(convert,"%d",FILE_NOT_FOUND);
                strcpy(message,convert);
                send(mysocket,message,strlen(message)+1,0); 
        } else if(gasit==1)
        {
                char message[20];
                char convert[20];
                sprintf(convert,"%d;",SUCCESS);
                strcpy(message,convert);
                strcat(message,"5");
                send(mysocket,message,strlen(message)+1,0); //am trimis codul si numarul octeti raspuns
                //o sa deschid fisierul
                int fd=open(r.caleFisier,O_RDONLY);
                int n=1;
                while(n>0)
                {
                        n=sendfile(mysocket,fd,0,BUF_SIZE);
                }
        }
        WriteIntoLogFile("DOWNLOAD",r.caleFisier,"");
}
void UploadFile(struct RequestFromClient r, int mysocket) {
        //asta inseamna ca voi scrie in memorie fisierul trimis de utilizator si il voi adauga si 
        //in coada de fisiere
        //stiind numele fisierului il voi crea prima data
        int numara=0;
         char *newCale=malloc(20);
        for(int i=0;i<strlen(r.caleFisier);i++)
        if(r.caleFisier[i]=='/') numara++;
        char *cale=strdup(r.caleFisier);
        if(numara==2){//merge doar pentru un singur director
                
                char*cale1;
                
                cale1=strtok_r(cale,"/",&cale);
                struct stat st;
                if(stat(cale1,&st)!=0)
                {
                        mkdir(cale1,0777);
                }
                char* newCale2=malloc(10);
               newCale2=strtok_r(cale,"/",&cale);
               strcpy(newCale,cale1);
               strcat(newCale,"/");
                strcat(newCale,newCale2);
               
        } else
       
        {newCale=strtok_r(cale,"/",&cale);}
        int fd=open(newCale,O_CREAT|O_WRONLY,0666);
        char buffer2[BUF_SIZE];
        bzero(buffer2,BUF_SIZE);
        int rec=read(mysocket,buffer2,BUF_SIZE);
        printf("%s\n",buffer2);
        write(fd,buffer2,strlen(buffer2));
        printf("Reusit\n");
        
        //trimit statusul
        char message[20];
        char convert[20];
        sprintf(convert,"%d",SUCCESS);
        strcpy(message,convert);
        send(mysocket,message,strlen(message)+1,0);
        WriteIntoLogFile("UPLOAD",r.caleFisier,"");
        pthread_mutex_lock(&MutexStart);
        x=0;
        pthread_mutex_unlock(&MutexStart);
        pthread_cond_signal(&cond);
        

}
void DeleteFile(struct RequestFromClient r, int mysocket)
{
        int gasit=0;
        for(int i=0;i<NumberOfFiles;i++)
        if(strcmp(r.caleFisier,CoadaFisiere[i].filename)==0)
        {gasit=1; break;}
        r.caleFisier=strdup(r.caleFisier+1);

        if(gasit==1)
        {
                int success;
                success=unlink(r.caleFisier);
                if(success==0) {
                
                char message[20];
                char convert[20];
                sprintf(convert,"%d",SUCCESS);
                strcpy(message,convert);
                send(mysocket,message,strlen(message)+1,0);
                }
                else{
                        char message[20];
                        char convert[20];
                sprintf(convert,"%d",PERMISSION_DENIED);
                strcpy(message,convert);//daca nu a putut fi sters inseamna ca nu are 
                // permisiuni pentru aceasta operatie
                send(mysocket,message,strlen(message)+1,0);
                }
        }
        else{
                //fisierul nu a fost gasit
                char message[20];
                char convert[20];
                sprintf(convert,"%d",FILE_NOT_FOUND);
                strcpy(message,convert);
                send(mysocket,message,strlen(message)+1,0);
        }
        WriteIntoLogFile("DELETE",r.caleFisier,"");
        pthread_mutex_lock(&MutexStart);
        x=0;
        pthread_mutex_unlock(&MutexStart);
        pthread_cond_signal(&cond);
        
}
void MoveFile(struct RequestFromClient r, int mysocket)
{
        r.caleFisier=strdup(r.caleFisier+1);
        r.caleFisierDestinatie=strdup(r.caleFisierDestinatie+1);
        printf("%s %s\n",r.caleFisier,r.caleFisierDestinatie);
       int n= rename(r.caleFisier,r.caleFisierDestinatie);
       if(n==0)
       {
        unlink(r.caleFisier);
        //o sa inlocuim si in coada de fisiere numele vechi cu cel nou
        char message[20];
        char convert[20];
        sprintf(convert,"%d",SUCCESS);
        strcpy(message,convert);
        send(mysocket,message,strlen(message)+1,0);
       }else{
        char message[20];
        char convert[20];
        sprintf(convert,"%d",OTHER_ERROR);
        strcpy(message,convert);
        send(mysocket,message,strlen(message)+1,0);
       }
        WriteIntoLogFile("MOVE",r.caleFisier,"");
        pthread_mutex_lock(&MutexStart);
        x=0;
        pthread_mutex_unlock(&MutexStart);
        pthread_cond_signal(&cond);
        
}
void UpdateFile(struct RequestFromClient r, int mysocket){
        //verificam daca exista fisierul
        int gasit=0;
        // r.caleFisier=strdup(r.caleFisier+1);
        for(int i=0;i<NumberOfFiles;i++)
        if(strcmp(r.caleFisier,CoadaFisiere[i].filename)==0){
                gasit=1;
                break;
        }
        if(gasit==1)
        {
                r.caleFisier=strdup(r.caleFisier+1);
                int fd=open(r.caleFisier,O_WRONLY);
                if(fd<0) printf("eroare la deschiderea fisierului!\n");
                lseek(fd,r.octetStart,SEEK_SET);
                char buffer[10000];
                size_t bytesRead = read(fd,buffer,10000);
               
                lseek(fd,r.octetStart,SEEK_SET);
                
                int n=write(fd,r.NewCharacters,r.dimensiuneContinutNou);
                lseek(fd,r.octetStart+1,SEEK_SET);
                write(fd,buffer,strlen(buffer));
                close(fd);
               
                if(n<0)
                {       //rewind(fd);
                        lseek(fd,0,SEEK_SET);
                        char message[20];
                        char convert[20];
                        sprintf(convert,"%d",PERMISSION_DENIED);
                        strcpy(message,convert);
                        send(mysocket,message,strlen(message)+1,0); 
                }
                else {
                        //rewind(fd);
                        lseek(fd,0,SEEK_SET);
                        char message[20];
                        char convert[20];
                        sprintf(convert,"%d",SUCCESS);
                        strcpy(message,convert);
                        send(mysocket,message,strlen(message)+1,0);
                 }
        }
        else {
                        char message[20];
                        char convert[20];
                        sprintf(convert,"%d",FILE_NOT_FOUND); 
                        strcpy(message,convert);
                        send(mysocket,message,strlen(message)+1,0);
        }
        WriteIntoLogFile("UPDATE",r.caleFisier,r.NewCharacters);
        
        pthread_mutex_lock(&MutexStart);
        x=0;
        pthread_mutex_unlock(&MutexStart);
        pthread_cond_signal(&cond);
    
       
}
void SearchFile(struct RequestFromClient r, int mysocket){
        char message[200],message2[200];
        char convert[20];
        sprintf(convert,"%d",SUCCESS);
        strcpy(message,convert);
        strcat(message,";");
        printf("%s\n",r.Cuvant); char nullchar='\0'; int lenghtmessage=0;
    
        for(int i=0;i<NumberOfFiles;i++)
        {
                for(int j=0;j<10;j++)
                {
                        if(strcmp(r.Cuvant,CoadaFisiere[i].cuvinte[j])==0)
                        {
                               lenghtmessage+=strlen(CoadaFisiere[i].filename);
                                memcpy(message2+strlen(message2),CoadaFisiere[i].filename,lenghtmessage);
                                memcpy(message2+strlen(message2),&nullchar,1);
                                WriteIntoLogFile("SEARCH",CoadaFisiere[i].filename,r.Cuvant);
                        }
                }
        }
        char lungime[20];
        sprintf(lungime,"%d",lenghtmessage);
        strcat(message,lungime);
        strcat(message,";");
        memcpy(message+strlen(message),message2,lenghtmessage);
        send(mysocket,message,strlen(message)+1,MSG_DONTWAIT);
        
        
}
void *HandleRequests(void*param)
{
        printf("Aici se va prelucra mesajul!\n");
        //aici se analizeaza mesajul de la client si se creeaza thread-ul pentru executarea cererii
        struct sendThread *details=(struct sendThread*)malloc(sizeof(struct sendThread));
        details=(struct sendThread*)param;
        //HINT: strtok_r e considerat thdread safe asa ca-l folosim pe asta
        //pthread_exit(NULL);
        char *cod_mesaj;
        char *rest=strdup(details->buffer);
        printf("%s\n",rest);
        cod_mesaj=strtok_r(rest,";",&rest);
        char* someend;
        long int codMesaj=strtol(cod_mesaj,&someend,16);
        struct RequestFromClient cerere;
        if(codMesaj==0x0){

                printf("%ld\n",codMesaj);
                cerere.RequestType=LIST;
                ListFiles(cerere,details->serverSock);

        } 
        else if(codMesaj==0x1)
        {
                char* nrOctetiCaleFisier=strtok_r(rest,";",&rest);
                cerere.RequestType=DOWNLOAD;
                //cerere.dimensiune=atoi
                char *endptr;
                unsigned long longValue=strtoul(nrOctetiCaleFisier,&endptr,10);

                if(*endptr!='\0')
                {
                        //daca nu reuseste conversia inseamna ca utilizatorul
                        // a trimis un parametru gresit si trimitem cod de eroare si inchidem conexiunea
                        char *mesajCatreUtilizator=strdup("0x20");
                        printf("Conversia nu a reusit! Se inchide conexiunea!\n");
                        send(details->serverSock,mesajCatreUtilizator,strlen(mesajCatreUtilizator)+1,0);
                        close(details->serverSock);
                }
                uint32_t val=(uint32_t)longValue;
                cerere.dimensiune=val;

                cerere.caleFisier=strtok_r(rest,";",&rest);

                DownloadFile(cerere,details->serverSock);
        } 
        else if(codMesaj==0x2)
        {
                char* nrOctetiCaleFisier=strtok_r(rest,";",&rest);
                cerere.RequestType=UPLOAD;
        
                char *endptr;
                unsigned long longValue=strtoul(nrOctetiCaleFisier,&endptr,10);

                if(*endptr!='\0')
                {
                        char *mesajCatreUtilizator=strdup("0x20");
                        printf("Conversia nu a reusit! Se inchide conexiunea!\n");
                        send(details->serverSock,mesajCatreUtilizator,strlen(mesajCatreUtilizator)+1,0);
                        close(details->serverSock);
                }
                uint32_t val=(uint32_t)longValue;
                cerere.dimensiune=val;

                cerere.caleFisier=strtok_r(rest,";",&rest);

                char* nrOctetiCaleFisier2=strtok_r(rest,";",&rest);
                char *endptr2;
                unsigned long longValue2=strtoul(nrOctetiCaleFisier2,&endptr2,10);

                if(*endptr2!='\0')
                {
                        char *mesajCatreUtilizator=strdup("0x20");
                        printf("Conversia nu a reusit 2! Se inchide conexiunea! 2\n");
                        send(details->serverSock,mesajCatreUtilizator,strlen(mesajCatreUtilizator)+1,0);
                        close(details->serverSock);
                }
                cerere.dimensiuneContFisier=(uint32_t)longValue2;
                UploadFile(cerere,details->serverSock);
        }else if(codMesaj==0x4)
        {
                char* nrOctetiCaleFisier=strtok_r(rest,";",&rest);
                cerere.RequestType=DELETE;
                //cerere.dimensiune=atoi
                char *endptr;
                unsigned long longValue=strtoul(nrOctetiCaleFisier,&endptr,10);

                if(*endptr!='\0')
                {
                        char *mesajCatreUtilizator=strdup("0x20");
                        printf("Conversia nu a reusit! Se inchide conexiunea!\n");
                        send(details->serverSock,mesajCatreUtilizator,strlen(mesajCatreUtilizator)+1,0);
                        close(details->serverSock);
                }
                
                cerere.dimensiune=(uint32_t)longValue;

                cerere.caleFisier=strtok_r(rest,";",&rest);
                DeleteFile(cerere,details->serverSock);
        } else if(codMesaj==0x8)
        {
                char* nrOctetiCaleFisier=strtok_r(rest,";",&rest);
                cerere.RequestType=MOVE;
         
                char *endptr;
                unsigned long longValue=strtoul(nrOctetiCaleFisier,&endptr,10);

                if(*endptr!='\0')
                {
                        char *mesajCatreUtilizator=strdup("0x20");
                        printf("Conversia nu a reusit! Se inchide conexiunea!\n");
                        send(details->serverSock,mesajCatreUtilizator,strlen(mesajCatreUtilizator)+1,0);
                        close(details->serverSock);
                }
                
                cerere.dimensiune=(uint32_t)longValue;
                cerere.caleFisier=strtok_r(rest,";",&rest);
                char* nrOctetiCaleFisier2=strtok_r(rest,";",&rest);
              
                char *endptr2;
                unsigned long longValue2=strtoul(nrOctetiCaleFisier2,&endptr2,10);

                if(*endptr2!='\0')
                {
                        char *mesajCatreUtilizator=strdup("0x20");
                        printf("Conversia nu a reusit! Se inchide conexiunea!\n");
                        send(details->serverSock,mesajCatreUtilizator,strlen(mesajCatreUtilizator)+1,0);
                        close(details->serverSock);
                }
                
                cerere.dimensiuneDestinatie=(uint32_t)longValue2;

                cerere.caleFisierDestinatie=strtok_r(rest,";",&rest);
                
                MoveFile(cerere,details->serverSock);
        } else if(codMesaj==0x10)
        {
                char* nrOctetiCaleFisier=strtok_r(rest,";",&rest);
                cerere.RequestType=UPDATE;
                printf("%ld\n",codMesaj);
                char *endptr;
                unsigned long longValue=strtoul(nrOctetiCaleFisier,&endptr,10);

                if(*endptr!='\0')
                {
                        char *mesajCatreUtilizator=strdup("0x20");
                        printf("Conversia nu a reusit! Se inchide conexiunea!\n");
                        send(details->serverSock,mesajCatreUtilizator,strlen(mesajCatreUtilizator)+1,0);
                        close(details->serverSock);
                }
                
                cerere.dimensiune=(uint32_t)longValue;
                cerere.caleFisier=strtok_r(rest,";",&rest);

                char* octetstart=strtok_r(rest,";",&rest);
                char *endptr2;
                unsigned long longValue2=strtoul(octetstart,&endptr2,10);

                if(*endptr2!='\0')
                {
                        char *mesajCatreUtilizator=strdup("0x20");
                        printf("Conversia nu a reusit! Se inchide conexiunea!\n");
                        send(details->serverSock,mesajCatreUtilizator,strlen(mesajCatreUtilizator)+1,0);
                        close(details->serverSock);
                }

                cerere.octetStart=(uint32_t)longValue2;
                char* dimensiuneC=strtok_r(rest,";",&rest);

                char *endptr3;
                unsigned long longValue3=strtoul(dimensiuneC,&endptr3,10);

                if(*endptr3!='\0')
                {
                        char *mesajCatreUtilizator=strdup("0x20");
                        printf("Conversia nu a reusit! Se inchide conexiunea!\n");
                        send(details->serverSock,mesajCatreUtilizator,strlen(mesajCatreUtilizator)+1,0);
                        close(details->serverSock);
                }
                cerere.dimensiuneContinutNou=(uint32_t)longValue3;
                cerere.NewCharacters=strtok_r(rest,";",&rest);

                UpdateFile(cerere,details->serverSock);
        } else if(codMesaj==0x20)
        {
                char* nrOctetiCuvant=strtok_r(rest,";",&rest);
                cerere.RequestType=SEARCH;
         
                char *endptr;
                unsigned long longValue=strtoul(nrOctetiCuvant,&endptr,10);

                if(*endptr!='\0')
                {
                        char *mesajCatreUtilizator=strdup("0x20");
                        printf("Conversia nu a reusit! Se inchide conexiunea!\n");
                        send(details->serverSock,mesajCatreUtilizator,strlen(mesajCatreUtilizator)+1,0);
                        close(details->serverSock);
                }
                
                cerere.NrOctetiCuvant=(uint32_t)longValue;
                cerere.Cuvant=strtok_r(rest,"\0",&rest);
                SearchFile(cerere,details->serverSock);
        } else{
                //asta inseamna ca mesajul primit de la client este invalid si o sa trimitem inapoi
                // un cod de eroare catre client
                // in cazul asta cel mai bun cod este de unknown operation
                char *mesajCatreUtilizator=strdup("0x10");

                send(details->serverSock,mesajCatreUtilizator,strlen(mesajCatreUtilizator)+1,0);
                close(details->serverSock);
               // pthread_exit(NULL);
        } 
        pthread_exit(NULL);
}

void *listen_thread(void *param)
{
        //am sa apelez functia de createSocket aici pentru ca socket-ul asta va fi activ continuu
        int socketprincipal=CreateSocket();
        int newsocket;
        struct sockaddr_storage serverStorage;
        socklen_t addr_size;
        char buffer[4096];
        bzero(buffer,4096);
        printf("A pornit\n");
        //sleep(1);
        while(terminare==0)
        {
                addr_size=sizeof(serverStorage);
                newsocket=accept(socketprincipal,(struct sockaddr*)&serverStorage,&addr_size);
                if(newsocket!=-1){
                if(CurrentNumberOfClients<MAX_CLIENTI){
                if(newsocket>=0) printf("Client conectat!\n");
                //aici o sa ascult pentru fiecare client si o sa creez un nou thread 
                //pentru fiecare client in parte ca sa execute sarcinile primite de la client
                recv(newsocket,&buffer,4096,0);//ascult mesajul de la client
                //creez threadul pentru client
                struct sendThread *details=(struct sendThread*)malloc(sizeof(struct sendThread));
                strcpy(details->buffer,buffer);
                details->serverSock=newsocket; //ca serverul sa poata trimita inapoi pe socket raspunsul
                pthread_create(&threadClienti[CurrentNumberOfClients],NULL,HandleRequests,(void*)details);

                pthread_mutex_lock(&ProtectClients);
                CurrentNumberOfClients++;//aici protejam variabila prin care sunt incrementati numarul de clienti
                pthread_mutex_unlock(&ProtectClients);

                //momentan las asa
                bzero(buffer,4096);
                printf("Urmatorul client!\n");
                }
                else{
                    //trebuie doar sa ii trimitem un mesaj cu server busy si sa inchidem conexiunea
                    char message[200];
                    char convert[20];
                    sprintf(convert,"%d",SERVER_BUSY);
                    strcpy(message,convert);
                    int n=send(newsocket,message,strlen(message),0);
                    if(n<0) printf("Eroare la trimiterea mesajului-- generata de SERVER_BUSY!\n");
                    else printf("S-a trimis server busy\n");
                    // close(newsocket); //am inchis conexiunea cu clientul
                    pthread_mutex_lock(&ProtectClients);
                    CurrentNumberOfClients--;//aici protejam variabila prin care sunt decrementati numarul de clienti
                    pthread_mutex_unlock(&ProtectClients);
                    close(newsocket);
                }
                }
        }
        for(int i=0;i<CurrentNumberOfClients;i++)
        pthread_join(threadClienti[i],NULL);

        printf("Executia s-a terminat\n");

        //pthread_exit(NULL);
}
int main()
{
        signal(SIGINT,signal_handler);
        signal(SIGTERM,signal_handler);//gestionez cu functia de mai sus primirea semnalelor

        pthread_mutex_init(&MutexStart,NULL);
        pthread_mutex_init(&MutexStop,NULL);
        pthread_mutex_init(&ProtectClients,NULL);
        pthread_mutex_init(&protectFile,NULL);
        pthread_cond_init(&cond,NULL);
        
        pthread_create(&threadCalculeaza,NULL,DeterminaFrecventa,NULL);

        pthread_create(&threadPrincipal,NULL,listen_thread,NULL);
        
        pthread_create(&threadFinish,NULL,FinishExecution,NULL);
        
        pthread_join(threadPrincipal, NULL);
       
        return 0;
}